/*Sahit Mandala, CS536*/

/* A custom checked exception thrown when attempting to access/use
 * element in an empty SymTable, usually when putting/getting from table
 */
public class EmptySymTableException extends Exception {
}
