/*Sahit Mandala, CS536*/

/* A custom checked exception thrown when attempting to put an
 * idenfitier into a scope (HashMap) which already contains the another
 * identifier of the same name
 */
public class DuplicateSymException extends Exception {
}
